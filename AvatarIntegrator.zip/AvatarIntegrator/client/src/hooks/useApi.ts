import { useState } from 'react';
import axios from 'axios';
import { ResponseData } from '../types/api';

// Base URL for the FastAPI backend
// This can be easily changed to point to your actual API endpoint
const API_BASE_URL = 'https://meeting.appmatric.com:8000';

export default function useApi() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const fetchData = async (endpoint: string): Promise<ResponseData> => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Remove /api prefix if present for external API calls
      const apiEndpoint = endpoint.startsWith('/api/') 
        ? endpoint.substring(4) 
        : endpoint;
      
      const url = `${API_BASE_URL}${apiEndpoint}`;
      
      // Future Bearer token implementation
      // const headers = {
      //   'Authorization': `Bearer ${token}`
      // };
      
      // For demo purposes, we'll fallback to mock data if the API is not available
      // In production, you would want to use the actual API data
      try {
        const response = await axios.get(url, { timeout: 3000 });
        
        // Small delay to ensure smooth animations
        await new Promise(resolve => setTimeout(resolve, 300));
        
        return response.data;
      } catch (apiError) {
        console.warn('API connection failed, using default response data:', apiError);
        // Return mock data that matches the expected response structure based on endpoint
        return getMockDataForEndpoint(endpoint);
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('An unknown error occurred'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    fetchData,
    isLoading,
    error
  };
}

// Helper function to provide appropriate mock data based on endpoint
function getMockDataForEndpoint(endpoint: string): ResponseData {
  if (endpoint.includes('notes')) {
    return {
      total_notes: 12,
      unread_notes: 3,
      recent_notes: [
        { title: "Meeting notes", date: "Today" },
        { title: "Project ideas", date: "Yesterday" },
        { title: "Weekly summary", date: "3 days ago" }
      ]
    };
  }
  
  if (endpoint.includes('calendar')) {
    return {
      upcoming_events: [
        { title: "Team Meeting", time: "10:00 AM", date: "Today" },
        { title: "Client Call", time: "2:30 PM", date: "Today" },
        { title: "Project Review", time: "11:00 AM", date: "Tomorrow" }
      ]
    };
  }
  
  if (endpoint.includes('tasks')) {
    return {
      total_tasks: 15,
      completed_tasks: 8,
      priority_tasks: [
        { title: "Finish proposal", due: "Today" },
        { title: "Review code", due: "Tomorrow" },
        { title: "Update documentation", due: "Friday" }
      ]
    };
  }
  
  if (endpoint.includes('email')) {
    return {
      unread_count: 7,
      recent_emails: [
        { from: "John Smith", subject: "Project update", time: "10:23 AM" },
        { from: "Marketing Team", subject: "New campaign", time: "Yesterday" },
        { from: "Support", subject: "Ticket #45678", time: "Yesterday" }
      ]
    };
  }
  
  if (endpoint.includes('weather')) {
    return {
      current: { temp: "72°F", condition: "Sunny" },
      forecast: [
        { day: "Today", temp: "72°F", condition: "Sunny" },
        { day: "Tomorrow", temp: "75°F", condition: "Partly Cloudy" },
        { day: "Friday", temp: "68°F", condition: "Rain" }
      ]
    };
  }
  
  if (endpoint.includes('contacts')) {
    return {
      total_contacts: 128,
      recent_contacts: [
        { name: "Jane Doe", phone: "(555) 123-4567" },
        { name: "Mark Johnson", phone: "(555) 987-6543" },
        { name: "Sarah Williams", phone: "(555) 456-7890" }
      ]
    };
  }
  
  if (endpoint.includes('messages')) {
    return {
      unread_count: 5,
      recent_messages: [
        { from: "Team Chat", content: "Meeting postponed to 3PM", time: "Just now" },
        { from: "Jane", content: "Can you review the document?", time: "30m ago" },
        { from: "Support Group", content: "New ticket assigned to you", time: "1h ago" }
      ]
    };
  }
  
  if (endpoint.includes('reminders')) {
    return {
      today_count: 4,
      reminders: [
        { title: "Call client", time: "1:00 PM" },
        { title: "Take medication", time: "2:00 PM" },
        { title: "Team meeting", time: "3:00 PM" },
        { title: "Pick up groceries", time: "5:30 PM" }
      ]
    };
  }
  
  // Default fallback
  return {};
}
