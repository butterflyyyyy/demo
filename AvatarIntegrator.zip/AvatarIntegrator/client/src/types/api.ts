// Tile interface
export interface Tile {
  name: string;
  endpoint: string;
  icon: string;
  bgColor: string;
  textColor: string;
}

// Response data types
export interface Note {
  title: string;
  date: string;
}

export interface Event {
  title: string;
  time: string;
  date: string;
}

export interface Task {
  title: string;
  due: string;
}

export interface Email {
  from: string;
  subject: string;
  time: string;
}

export interface Weather {
  temp: string;
  condition: string;
  day?: string;  // Optional property for forecast days
}

export interface Contact {
  name: string;
  phone: string;
}

export interface Message {
  from: string;
  content: string;
  time: string;
}

export interface Reminder {
  title: string;
  time: string;
}

export interface ResponseData {
  // Notes
  total_notes?: number;
  unread_notes?: number;
  recent_notes?: Note[];
  
  // Calendar
  upcoming_events?: Event[];
  
  // Tasks
  total_tasks?: number;
  completed_tasks?: number;
  priority_tasks?: Task[];
  
  // Email
  unread_count?: number;
  recent_emails?: Email[];
  
  // Weather
  current?: Weather;
  forecast?: Weather[];
  
  // Contacts
  total_contacts?: number;
  recent_contacts?: Contact[];
  
  // Messages
  recent_messages?: Message[];
  
  // Reminders
  today_count?: number;
  reminders?: Reminder[];
}

// Tile data
export const tiles: Tile[] = [
  {
    name: 'Notes Summary',
    endpoint: '/api/notes/summary',
    icon: 'description',
    bgColor: 'bg-blue-100',
    textColor: 'text-blue-500'
  },
  {
    name: 'Calendar',
    endpoint: '/api/calendar/events',
    icon: 'calendar_today',
    bgColor: 'bg-green-100',
    textColor: 'text-green-500'
  },
  {
    name: 'Tasks',
    endpoint: '/api/tasks/all',
    icon: 'checklist',
    bgColor: 'bg-purple-100',
    textColor: 'text-purple-500'
  },
  {
    name: 'Email',
    endpoint: '/api/email/unread',
    icon: 'email',
    bgColor: 'bg-red-100',
    textColor: 'text-red-500'
  },
  {
    name: 'Weather',
    endpoint: '/api/weather/forecast',
    icon: 'wb_sunny',
    bgColor: 'bg-yellow-100',
    textColor: 'text-yellow-500'
  },
  {
    name: 'Contacts',
    endpoint: '/api/contacts/recent',
    icon: 'contacts',
    bgColor: 'bg-indigo-100',
    textColor: 'text-indigo-500'
  },
  {
    name: 'Messages',
    endpoint: '/api/messages/unread',
    icon: 'chat',
    bgColor: 'bg-teal-100',
    textColor: 'text-teal-500'
  },
  {
    name: 'Reminders',
    endpoint: '/api/reminders/today',
    icon: 'notifications',
    bgColor: 'bg-orange-100',
    textColor: 'text-orange-500'
  }
];
