import { useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';
import { ResponseData } from '../types/api';

interface ResponseAreaProps {
  isVisible: boolean;
  title: string;
  data: ResponseData | null;
}

export function ResponseArea({ isVisible, title, data }: ResponseAreaProps) {
  const responseRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isVisible && responseRef.current) {
      responseRef.current.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, [isVisible]);

  if (!isVisible || !data) return null;

  // Renders different content based on the response type
  const renderContent = () => {
    if (!data) return null;

    switch (title) {
      case 'Notes Summary':
        return (
          <div className="space-y-3">
            <div className="flex justify-between">
              <span>Total Notes:</span>
              <span className="font-medium">{data.total_notes}</span>
            </div>
            <div className="flex justify-between">
              <span>Unread Notes:</span>
              <span className="font-medium">{data.unread_notes}</span>
            </div>
            <div className="mt-2">
              <div className="font-medium mb-1">Recent Notes:</div>
              {data.recent_notes?.map((note, idx) => (
                <div key={idx} className="bg-blue-50 p-2 rounded mb-1">
                  <div className="font-medium">{note.title}</div>
                  <div className="text-xs text-gray-500">{note.date}</div>
                </div>
              ))}
            </div>
          </div>
        );
      
      case 'Calendar':
        return (
          <div className="space-y-3">
            <div className="font-medium">Upcoming Events:</div>
            {data.upcoming_events?.map((event, idx) => (
              <div key={idx} className="bg-green-50 p-2 rounded mb-1">
                <div className="font-medium">{event.title}</div>
                <div className="text-xs text-gray-500">{event.time}, {event.date}</div>
              </div>
            ))}
          </div>
        );
      
      case 'Tasks':
        return (
          <div className="space-y-3">
            <div className="flex justify-between">
              <span>Completed:</span>
              <span className="font-medium">{data.completed_tasks}/{data.total_tasks}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="bg-purple-500 h-2.5 rounded-full" 
                style={{width: `${(data.completed_tasks! / data.total_tasks!) * 100}%`}}
              ></div>
            </div>
            <div className="mt-2">
              <div className="font-medium mb-1">Priority Tasks:</div>
              {data.priority_tasks?.map((task, idx) => (
                <div key={idx} className="bg-purple-50 p-2 rounded mb-1 flex items-center">
                  <span className="material-icons text-purple-500 mr-2 text-sm">assignment</span>
                  <div>
                    <div className="font-medium">{task.title}</div>
                    <div className="text-xs text-gray-500">Due: {task.due}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      
      case 'Email':
        return (
          <div className="space-y-3">
            <div className="flex justify-between">
              <span>Unread Emails:</span>
              <span className="font-medium">{data.unread_count}</span>
            </div>
            <div className="mt-2">
              <div className="font-medium mb-1">Recent Emails:</div>
              {data.recent_emails?.map((email, idx) => (
                <div key={idx} className="bg-red-50 p-2 rounded mb-1">
                  <div className="font-medium">{email.subject}</div>
                  <div className="text-xs">From: {email.from}</div>
                  <div className="text-xs text-gray-500">{email.time}</div>
                </div>
              ))}
            </div>
          </div>
        );
      
      case 'Weather':
        return (
          <div className="space-y-3">
            <div className="flex items-center justify-center bg-yellow-50 p-3 rounded-lg">
              <span className="material-icons text-yellow-500 text-3xl mr-3">
                {data.current && data.current.condition.toLowerCase().includes('sunny') 
                  ? 'wb_sunny' 
                  : data.current?.condition.toLowerCase().includes('cloud') 
                    ? 'cloud' : 'thermostat'}
              </span>
              <div>
                <div className="text-lg font-medium">{data.current?.temp}</div>
                <div className="text-sm">{data.current?.condition}</div>
              </div>
            </div>
            <div className="mt-2">
              <div className="font-medium mb-1">Forecast:</div>
              <div className="flex space-x-2">
                {data.forecast?.map((day, idx) => (
                  <div key={idx} className="bg-blue-50 p-2 rounded flex-1 text-center">
                    <div className="font-medium">{day.day}</div>
                    <div className="material-icons text-blue-500 my-1">
                      {day.condition.toLowerCase().includes('sunny') 
                        ? 'wb_sunny' 
                        : day.condition.toLowerCase().includes('cloud') 
                          ? 'cloud' : 'thermostat'}
                    </div>
                    <div>{day.temp}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      
      case 'Contacts':
        return (
          <div className="space-y-3">
            <div className="flex justify-between">
              <span>Total Contacts:</span>
              <span className="font-medium">{data.total_contacts}</span>
            </div>
            <div className="mt-2">
              <div className="font-medium mb-1">Recent Contacts:</div>
              {data.recent_contacts?.map((contact, idx) => (
                <div key={idx} className="bg-indigo-50 p-2 rounded mb-1 flex items-center">
                  <div className="bg-indigo-200 rounded-full h-8 w-8 flex items-center justify-center mr-2">
                    <span className="material-icons text-indigo-500 text-sm">person</span>
                  </div>
                  <div>
                    <div className="font-medium">{contact.name}</div>
                    <div className="text-xs text-gray-500">{contact.phone}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      
      case 'Messages':
        return (
          <div className="space-y-3">
            <div className="flex justify-between">
              <span>Unread Messages:</span>
              <span className="font-medium">{data.unread_count}</span>
            </div>
            <div className="mt-2">
              <div className="font-medium mb-1">Recent Messages:</div>
              {data.recent_messages?.map((message, idx) => (
                <div key={idx} className="bg-teal-50 p-2 rounded mb-1">
                  <div className="flex justify-between">
                    <span className="font-medium">{message.from}</span>
                    <span className="text-xs text-gray-500">{message.time}</span>
                  </div>
                  <div className="text-sm mt-1">{message.content}</div>
                </div>
              ))}
            </div>
          </div>
        );
      
      case 'Reminders':
        return (
          <div className="space-y-3">
            <div className="flex justify-between">
              <span>Today's Reminders:</span>
              <span className="font-medium">{data.today_count}</span>
            </div>
            <div className="mt-2">
              {data.reminders?.map((reminder, idx) => (
                <div key={idx} className="bg-orange-50 p-2 rounded mb-1 flex items-center">
                  <span className="material-icons text-orange-500 mr-2 text-sm">notifications</span>
                  <div className="flex-1">
                    <div className="font-medium">{reminder.title}</div>
                    <div className="text-xs text-gray-500">{reminder.time}</div>
                  </div>
                  <span className="material-icons text-gray-400 text-sm">chevron_right</span>
                </div>
              ))}
            </div>
          </div>
        );
      
      default:
        return <div className="text-center">No data available</div>;
    }
  };

  return (
    <div ref={responseRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
      <div className="bg-white rounded-lg shadow-lg p-4">
        <div className="flex items-center mb-2">
          <div className="h-4 w-4 rounded-full bg-green-500 mr-2"></div>
          <h3 className="font-medium text-gray-700">{title}</h3>
        </div>
        <div className="text-gray-600 text-sm rounded-lg bg-gray-50 p-3">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}

export default ResponseArea;
