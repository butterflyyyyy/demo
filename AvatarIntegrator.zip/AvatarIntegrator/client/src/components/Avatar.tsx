import { useState, useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';

interface AvatarProps {
  isActive: boolean;
  isLoading: boolean;
  message: string;
  onClose: () => void;
}

export function Avatar({ isActive, isLoading, message, onClose }: AvatarProps) {
  const [isVisible, setIsVisible] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Handle animation when avatar becomes active/inactive
  useEffect(() => {
    if (isActive) {
      setIsVisible(true);
    } else {
      // Delay hiding until animation completes
      const timer = setTimeout(() => {
        setIsVisible(false);
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [isActive]);

  const containerClasses = cn(
    "fixed bottom-0 left-0 right-0 flex flex-col items-center px-4 pb-4 z-50 transition-transform duration-300 ease-in-out",
    isActive ? "transform translate-y-0" : "transform translate-y-full"
  );

  const bubbleClasses = cn(
    "bg-gradient-to-r from-blue-600 to-blue-500 text-white p-4 rounded-lg mb-2 w-full max-w-md shadow-lg",
    "clip-path-polygon-[0%_0%,_100%_0%,_100%_75%,_75%_75%,_40%_100%,_40%_75%,_0%_75%]",
    !message && "hidden"
  );

  const avatarClasses = cn(
    "bg-gradient-to-r from-blue-600 to-blue-400 text-white rounded-full h-16 w-16 flex items-center justify-center shadow-lg relative cursor-pointer",
    isActive && "avatar-pulse"
  );

  const statusClasses = cn(
    "absolute top-0 right-0 h-4 w-4 rounded-full border-2 border-white",
    isActive ? "bg-green-500" : "bg-gray-300"
  );

  return (
    <div ref={containerRef} className={containerClasses}>
      <div className={bubbleClasses}>
        <div className="text-sm font-medium">
          {isLoading ? (
            <div className="typing-indicator">
              <span className="inline-block h-2 w-2 bg-white rounded-full mx-[1px] opacity-70 animate-bounce-slow delay-100"></span>
              <span className="inline-block h-2 w-2 bg-white rounded-full mx-[1px] opacity-70 animate-bounce-slow delay-300"></span>
              <span className="inline-block h-2 w-2 bg-white rounded-full mx-[1px] opacity-70 animate-bounce-slow delay-500"></span>
            </div>
          ) : (
            message
          )}
        </div>
      </div>
      
      <div className="flex items-center justify-center">
        <div 
          className={avatarClasses} 
          onClick={onClose}
        >
          <div className={cn("transition-all duration-300", !isLoading && isActive && "animate-wave")}>
            <span className="material-icons text-2xl">smart_toy</span>
          </div>
          <div className={statusClasses}></div>
        </div>
      </div>
    </div>
  );
}

export default Avatar;
