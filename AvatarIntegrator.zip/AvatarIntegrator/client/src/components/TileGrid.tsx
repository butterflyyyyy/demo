import { useState } from 'react';
import { Tile } from '../types/api';

interface TileGridProps {
  tiles: Tile[];
  onTileClick: (tile: Tile) => void;
}

export function TileGrid({ tiles, onTileClick }: TileGridProps) {
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <h2 className="text-lg font-medium text-gray-700 mb-4">Select a service</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {tiles.map((tile, index) => (
          <div 
            key={index}
            className="tile bg-white rounded-lg shadow overflow-hidden cursor-pointer hover:translate-y-[-5px] active:scale-[0.98] transition-all duration-200"
            onClick={() => onTileClick(tile)}
          >
            <div className="p-4">
              <div className={`${tile.bgColor} ${tile.textColor} rounded-full h-12 w-12 flex items-center justify-center mx-auto mb-2`}>
                <span className="material-icons">{tile.icon}</span>
              </div>
              <h3 className="text-center text-sm font-medium text-gray-700">{tile.name}</h3>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}

export default TileGrid;
