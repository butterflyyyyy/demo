import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add meta tags for better mobile experience
const meta = document.createElement('meta');
meta.name = 'viewport';
meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1';
document.getElementsByTagName('head')[0].appendChild(meta);

// Add title
const title = document.createElement('title');
title.textContent = 'Virtual Assistant';
document.getElementsByTagName('head')[0].appendChild(title);

// Add Google Fonts
const fontLink = document.createElement('link');
fontLink.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap';
fontLink.rel = 'stylesheet';
document.getElementsByTagName('head')[0].appendChild(fontLink);

// Add Material Icons
const iconLink = document.createElement('link');
iconLink.href = 'https://fonts.googleapis.com/icon?family=Material+Icons';
iconLink.rel = 'stylesheet';
document.getElementsByTagName('head')[0].appendChild(iconLink);

createRoot(document.getElementById("root")!).render(<App />);
