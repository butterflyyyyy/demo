import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import AppHeader from '@/components/AppHeader';
import TileGrid from '@/components/TileGrid';
import Avatar from '@/components/Avatar';
import ResponseArea from '@/components/ResponseArea';
import { tiles } from '@/types/api';
import useApi from '@/hooks/useApi';
import { ResponseData, Tile } from '@/types/api';

export default function Home() {
  const [isAvatarActive, setIsAvatarActive] = useState(false);
  const [currentTile, setCurrentTile] = useState<Tile | null>(null);
  const [avatarMessage, setAvatarMessage] = useState('');
  const { fetchData, isLoading } = useApi();
  const [responseData, setResponseData] = useState<ResponseData | null>(null);

  const handleTileClick = (tile: Tile) => {
    setCurrentTile(tile);
    setIsAvatarActive(true);
    
    // Call API 
    fetchData(tile.endpoint)
      .then(data => {
        setResponseData(data);
        // Generate message based on response data
        setAvatarMessage(getResponseMessage(tile.name, data));
      })
      .catch(error => {
        console.error('API Error:', error);
        setAvatarMessage('Sorry, I encountered an error. Please try again.');
      });
  };

  const handleAvatarClose = () => {
    setIsAvatarActive(false);
    setCurrentTile(null);
    setResponseData(null);
    setAvatarMessage('');
  };

  // Generate appropriate message based on the data and API type
  const getResponseMessage = (apiName: string, data: ResponseData): string => {
    switch (apiName) {
      case 'Notes Summary':
        return `You have ${data.total_notes} notes, with ${data.unread_notes} unread.`;
      case 'Calendar':
        return `You have ${data.upcoming_events?.length} upcoming events today.`;
      case 'Tasks':
        return `You have ${data.total_tasks! - data.completed_tasks!} tasks remaining.`;
      case 'Email':
        return `You have ${data.unread_count} unread emails.`;
      case 'Weather':
        return `Current weather: ${data.current?.temp}, ${data.current?.condition}.`;
      case 'Contacts':
        return `You have ${data.total_contacts} contacts saved.`;
      case 'Messages':
        return `You have ${data.unread_count} unread messages.`;
      case 'Reminders':
        return `You have ${data.today_count} reminders for today.`;
      default:
        return "How can I help you today?";
    }
  };

  return (
    <div className="bg-gray-100 font-sans min-h-screen">
      <AppHeader title="Virtual Assistant" />
      <TileGrid tiles={tiles} onTileClick={handleTileClick} />
      
      <ResponseArea 
        isVisible={isAvatarActive && !!responseData} 
        title={currentTile?.name || ''} 
        data={responseData} 
      />
      
      <Avatar 
        isActive={isAvatarActive}
        isLoading={isLoading}
        message={avatarMessage}
        onClose={handleAvatarClose}
      />

      {/* Add custom animations */}
      <style jsx global>{`
        .avatar-pulse {
          box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.7);
          animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
          0% {
            box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.7);
          }
          70% {
            box-shadow: 0 0 0 15px rgba(59, 130, 246, 0);
          }
          100% {
            box-shadow: 0 0 0 0 rgba(59, 130, 246, 0);
          }
        }
        
        .clip-path-polygon-\\[0\\%_0\\%\\,_100\\%_0\\%\\,_100\\%_75\\%\\,_75\\%_75\\%\\,_40\\%_100\\%\\,_40\\%_75\\%\\,_0\\%_75\\%\\] {
          clip-path: polygon(0% 0%, 100% 0%, 100% 75%, 75% 75%, 40% 100%, 40% 75%, 0% 75%);
        }
        
        .animate-bounce-slow {
          animation: bounce 1s infinite;
        }
        
        .delay-100 {
          animation-delay: 0.1s;
        }
        
        .delay-300 {
          animation-delay: 0.3s;
        }
        
        .delay-500 {
          animation-delay: 0.5s;
        }
        
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-5px); }
        }
        
        @keyframes wave {
          0% { transform: rotate(0.0deg); }
          10% { transform: rotate(14.0deg); }
          20% { transform: rotate(-8.0deg); }
          30% { transform: rotate(14.0deg); }
          40% { transform: rotate(-4.0deg); }
          50% { transform: rotate(10.0deg); }
          60% { transform: rotate(0.0deg); }
          100% { transform: rotate(0.0deg); }
        }
        
        .animate-wave {
          animation: wave 1.5s ease-in-out;
        }
      `}</style>
    </div>
  );
}
