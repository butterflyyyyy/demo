import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import axios from "axios";

// FastAPI Backend URL
const API_BASE_URL = "https://meeting.appmatric.com:8000";

export async function registerRoutes(app: Express): Promise<Server> {
  // API proxy routes to forward requests to FastAPI backend
  
  // Notes endpoint
  app.get("/api/notes/summary", async (req, res) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/notes/summary`);
      res.json(response.data);
    } catch (error) {
      console.error("Error fetching notes:", error);
      res.status(500).json({ message: "Failed to fetch notes data" });
    }
  });

  // Calendar endpoint
  app.get("/api/calendar/events", async (req, res) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/calendar/events`);
      res.json(response.data);
    } catch (error) {
      console.error("Error fetching calendar events:", error);
      res.status(500).json({ message: "Failed to fetch calendar data" });
    }
  });

  // Tasks endpoint
  app.get("/api/tasks/all", async (req, res) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/tasks/all`);
      res.json(response.data);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks data" });
    }
  });

  // Email endpoint
  app.get("/api/email/unread", async (req, res) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/email/unread`);
      res.json(response.data);
    } catch (error) {
      console.error("Error fetching emails:", error);
      res.status(500).json({ message: "Failed to fetch email data" });
    }
  });

  // Weather endpoint
  app.get("/api/weather/forecast", async (req, res) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/weather/forecast`);
      res.json(response.data);
    } catch (error) {
      console.error("Error fetching weather:", error);
      res.status(500).json({ message: "Failed to fetch weather data" });
    }
  });

  // Contacts endpoint
  app.get("/api/contacts/recent", async (req, res) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/contacts/recent`);
      res.json(response.data);
    } catch (error) {
      console.error("Error fetching contacts:", error);
      res.status(500).json({ message: "Failed to fetch contacts data" });
    }
  });

  // Messages endpoint
  app.get("/api/messages/unread", async (req, res) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/messages/unread`);
      res.json(response.data);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages data" });
    }
  });

  // Reminders endpoint
  app.get("/api/reminders/today", async (req, res) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/reminders/today`);
      res.json(response.data);
    } catch (error) {
      console.error("Error fetching reminders:", error);
      res.status(500).json({ message: "Failed to fetch reminders data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
