import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const apiRequests = pgTable("api_requests", {
  id: serial("id").primaryKey(),
  endpoint: text("endpoint").notNull(),
  timestamp: text("timestamp").notNull(),
  userId: integer("user_id").references(() => users.id),
  successful: boolean("successful").notNull().default(true),
  responseTime: integer("response_time"),
  responseData: jsonb("response_data")
});

export const avatarSettings = pgTable("avatar_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  activeColor: text("active_color").default("#3B82F6"),
  animationEnabled: boolean("animation_enabled").default(true),
  soundEnabled: boolean("sound_enabled").default(false)
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertApiRequestSchema = createInsertSchema(apiRequests).pick({
  endpoint: true, 
  timestamp: true,
  userId: true,
  successful: true,
  responseTime: true,
  responseData: true
});

export const insertAvatarSettingsSchema = createInsertSchema(avatarSettings).pick({
  userId: true,
  activeColor: true,
  animationEnabled: true,
  soundEnabled: true
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertApiRequest = z.infer<typeof insertApiRequestSchema>;
export type ApiRequest = typeof apiRequests.$inferSelect;

export type InsertAvatarSettings = z.infer<typeof insertAvatarSettingsSchema>;
export type AvatarSettings = typeof avatarSettings.$inferSelect;
